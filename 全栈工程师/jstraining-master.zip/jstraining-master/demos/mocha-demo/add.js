function add(x, y) {
  return x + y;
}

module.exports = add;
