const $ = require('jquery');
$('h1').css({ color: 'red'});
